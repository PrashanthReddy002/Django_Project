Title : Tweets and Post using Django Framework (demo)

Project Description : This project is a tweet post using the Django framework. Where users post tweets like titles and images. It also has operations like view, update, and delete. And Django uses the sqlite3 to 
store the users database
